<header>
    <nav class="navbar navbar-expand-lg bg-white py-3">
        <div class="container-fluid mx-sm-4">
            <div class='container'>
            <div class='row'>
                <div class='col-md-4 d-md-block justify-content-md-start d-flex justify-content-center'>
                    <a class="navbar-brand" href="{{ route('home') }}">
                        Ecosistema Canino
                    </a>
                </div>

                <div class='col-md-4 d-flex justify-content-center mt-md-0 mt-3'>
                    <form class="w-100" role="search" action="{{ route( 'blog.search' ) }}">
                        <input name="data" class="form-control me-1" type="search" placeholder="Buscar noticia..." aria-label="Bucar noticia" />
                    </form>
                </div>
                <div class='col-md-4 d-flex justify-content-end align-items-center'>

                </div>
            </div>
            </div>
        </div>
    </nav>
</header>
