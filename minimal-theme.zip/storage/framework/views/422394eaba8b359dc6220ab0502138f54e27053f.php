

<?php $__env->startSection('css'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/posts.css']); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', $veterinary->name); ?>

<?php $__env->startSection('description', $veterinary->extract); ?>
<?php $__env->startSection('keywords', $veterinary->keywords); ?>

<?php $__env->startSection('content'); ?>

    <article class="entry-content">
        <section class="justify-content-center pt-5 d-flex">
            <div class="container-compact">
                <a href="<?php echo e(URL::previous()); ?>" class="text-decoration-none">Regresar</a>
            </div>
        </section>

        <section class="justify-content-center py-5 d-flex">
            <div class="container-compact">
                <div class="row w-100">
                    <div class="col-lg-3 d-flex justify-content-lg-start justify-content-center">
                        <img src="<?php echo e($veterinary->logo); ?>" class="rounded-circle" alt="<?php echo e($veterinary->name); ?>"
                            style="height: 150px; width: 150px;" />

                    </div>
                    <div class="col-lg-9">
                        <h1 class="mt-3 text-lg-start text-center"><?php echo e($veterinary->name); ?></h1>
                        <p class="mt-0 text-lg-start text-center"> <?php echo e($veterinary->address->first()->country); ?>,
                            <?php echo e($veterinary->address->first()->city); ?></p>
                    </div>
                </div>
            </div>
        </section>

        <section class="justify-content-center pt-1 d-flex">
            <div class="container-compact">
                <div class="row w-100">
                    <div class="col-lg-3">
                        <h6>Contacto</h6>
                        <?php $__currentLoopData = $veterinary->phone; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $phone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p class="mt-0"><?php echo e($phone->phone); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="col-lg-3">
                        <h6>Direcciones</h6>
                        <?php $__currentLoopData = $veterinary->address; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p class="mt-0"><?php echo e($address->country); ?>, <?php echo e($address->city); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <div class="col-lg-3">
                        <h6>Correo electrónico</h6>
                        <p class="mt-0"><?php echo e($veterinary->email); ?></p>
                    </div>

                    <div class="col-lg-3">
                        <h6>Sitio web</h6>
                        <p class="mt-0"><?php echo e($veterinary->website); ?></p>
                    </div>
                </div>
            </div>
        </section>

        <section class="d-flex justify-content-center">
            <section class="container-compact">
                <h2>Descripción</h2>
                <?php echo Str::markdown($veterinary->description); ?>

            </section>
        </section>

        <section class="justify-content-center mt-1 d-flex">
            <div class="container-compact">
                <h2>Servicios</h2>
                <div class="row w-100">
                    <?php $__currentLoopData = $veterinary->services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <article class="col-lg-3 col-md-4 col-sm-6 py-3">
                            <div class="card">
                                <div class="card-body text-center">
                                    
                                    <h6 class="text-reset"><?php echo e($service->name); ?></h6>
                                </div>
                            </div>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>

    </article>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.general', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\minimal-theme\resources\views/guest/veterinary.blade.php ENDPATH**/ ?>