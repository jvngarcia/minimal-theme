<?php $__env->startSection('css'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/posts.css']); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', $search); ?>

<?php $__env->startSection('content'); ?>
    <h1><?php echo e($search); ?></h1>


    <?php if(count($posts) > 0): ?>
        <p>Puedes ver todos los resultados de búsqueda</p>
        <section class="row">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <article class="col-lg-3 col-md-4 col-sm-6 py-3">
                    <a href="<?php echo e(route('blog.show', $post->slug)); ?>" class="text-decoration-none text-reset">
                        <div class="card mx-1">
                            <img src="<?php echo e($post->image); ?>" class="card-img-top img-fluid" alt="<?php echo e($post->name); ?>" />
                            <div class="card-body">
                                <a href="<?php echo e(route('blog.category', $post->categories)); ?>"
                                    class="card-category text-decoration-none"><?php echo e($post->categories->name); ?></a>
                                <h6 class="card-title"><?php echo e($post->name); ?></h6>
                                <div class="d-flex justify-content-between">
                                    <p class="card-text card-author mb-0"><?php echo e($post->authors->name); ?></p>
                                    <p class="card-text card-date"><?php echo e(date('M Y', strtotime($post->created_at))); ?></p>
                                </div>
                            </div>
                        </div>
                    </a>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </section>
    <?php else: ?>
        <p>No se encontraron resultados para tu <strong>búsqueda</strong></p>
    <?php endif; ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.general', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\minimal-theme\resources\views/guest/search.blade.php ENDPATH**/ ?>