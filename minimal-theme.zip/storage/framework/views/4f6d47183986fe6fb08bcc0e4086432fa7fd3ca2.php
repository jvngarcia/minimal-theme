<?php $__env->startSection('css'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/posts.css']); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'No se encontraron resultados'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Página no encontrada</h1>
    <p>La página que buscas no existe o no se encuentra disponible</p>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.general', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\minimal-theme\resources\views/errors/404.blade.php ENDPATH**/ ?>