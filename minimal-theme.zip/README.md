# Minimal Theme for Laravel

Desarrollo de tema para un blog minimalista y profesional


TODO: Mejorar descripción y agregar imágenes
TODO: ¿Será en inglés o español?